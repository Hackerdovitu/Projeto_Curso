<html>
	<head>
		<meta charset="utf-8" />
    	<title>App Mail Send</title>

    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	</head>

	<body>

		<div class="container">  

			<div class="py-3 text-center">
				<img class="d-block mx-auto mb-2" src="img.png" alt="" width="72" height="72">
				<h2>Recuperar Senha</h2>
				<p class="lead">Cadastre seu e-mail abaixo que será enviado sua senha para o mesmo!!</p>
			</div>

      		<div class="row">
      		<div class="col-6" style="margin-left: 290px">
      			<div class="card-login">
  					<div class="card">
  				
						<div class="card-body font-weight-bold">
							<form action="recuperar_senha.php" method="post">
								<div class="form-group">
									<label for="para">Email de recuperação de senha:</label>
									<input name="email" type="email" class="form-control" id="para" placeholder="user@dominio.com.br">
								</div>
								<button name='ok' type="submit" class="btn btn-primary btn-lg btn-block">Enviar Mensagem</button>
							</form>
						</div>

					</div>
						<?php
							if (isset($_GET['erro']) && $_GET['erro'] == 'email') {
								echo '<div class="alert alert-danger text-center mt-3" role="alert">Email não encontrado</div>';
							}

							if (isset($_GET['enviado']) && $_GET['enviado'] == 'true') {
								echo '<div class="alert alert-success text-center mt-3" role="alert">Email enviado com sucesso! Cheque seu Email</div>';
							}
						?>
				</div>
      		</div>
      		</div>
      	</div>

	</body>
</html>